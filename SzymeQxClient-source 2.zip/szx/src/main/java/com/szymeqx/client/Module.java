package com.szymeqx.client;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;

public abstract class Module {
    protected static final MinecraftClient mc = MinecraftClient.getInstance();
    public final String name;
    public final Category category;
    public int key = -1;
    public boolean keyDown;
    private boolean enabled;

    public Module(String name, Category category) { this.name = name; this.category = category; }

    public boolean isEnabled() { return enabled; }
    public void toggle() { enabled = !enabled; if (enabled) onEnable(); else onDisable(); }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
    public void onRender(WorldRenderContext ctx) {}
}
