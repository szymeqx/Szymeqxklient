package com.szymeqx.client;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.entity.*;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public class Modules {

    // ---------------- PVP ----------------
    public static class KillAura extends Module {
        public KillAura() { super("Kill Aura", Category.PVP); }
        @Override public void onTick() {
            if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
            if (mc.player.getAttackCooldownProgress(0.5f) < 1f) return;
            PlayerEntity best = null; double bd = 4.5 * 4.5;
            for (PlayerEntity p : mc.world.getPlayers()) {
                if (p == mc.player || !p.isAlive() || p.isSpectator()) continue;
                double d = mc.player.squaredDistanceTo(p);
                if (d < bd) { bd = d; best = p; }
            }
            if (best == null) return; // brak sprawdzania linii wzroku = bicie przez sciany
            mc.interactionManager.attackEntity(mc.player, best);
            mc.player.swingHand(Hand.MAIN_HAND);
        }
    }

    public static class AutoTotem extends Module {
        public AutoTotem() { super("Auto Totem", Category.PVP); }
        @Override public void onTick() {
            if (mc.player == null || mc.interactionManager == null || mc.currentScreen != null) return;
            if (mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
            for (int i = 0; i < 36; i++) {
                if (mc.player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                    int slot = i < 9 ? i + 36 : i;
                    mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, mc.player);
                    return;
                }
            }
        }
    }

    // ---------------- MOVEMENT ----------------
    public static class Sprint extends Module {
        public Sprint() { super("Sprint", Category.MOVEMENT); }
        @Override public void onTick() {
            if (mc.player == null) return;
            if (mc.player.input.movementForward > 0 && !mc.player.horizontalCollision) mc.player.setSprinting(true);
        }
    }

    public static class Flight extends Module {
        public Flight() { super("Flight", Category.MOVEMENT); }
        @Override public void onTick() {
            if (mc.player == null) return;
            mc.player.getAbilities().allowFlying = true;
            mc.player.getAbilities().flying = true;
            mc.player.getAbilities().setFlySpeed(0.08f);
        }
        @Override public void onDisable() {
            if (mc.player == null) return;
            if (!mc.player.isCreative() && !mc.player.isSpectator()) {
                mc.player.getAbilities().allowFlying = false;
                mc.player.getAbilities().flying = false;
            }
            mc.player.getAbilities().setFlySpeed(0.05f);
        }
    }

    public static class Step extends Module {
        public Step() { super("Step", Category.MOVEMENT); }
        @Override public void onTick() {
            if (mc.player == null) return;
            var a = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
            if (a != null) a.setBaseValue(2.0);
        }
        @Override public void onDisable() {
            if (mc.player == null) return;
            var a = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
            if (a != null) a.setBaseValue(0.6);
        }
    }

    public static class NoFall extends Module {
        public NoFall() { super("No Fall", Category.MOVEMENT); }
        @Override public void onTick() {
            if (mc.player == null || mc.player.networkHandler == null) return;
            if (mc.player.fallDistance > 2f)
                mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true, mc.player.horizontalCollision));
        }
    }

    // ---------------- VISUAL ----------------
    public static class PlayerEsp extends Module {
        public PlayerEsp() { super("Player Esp", Category.VISUAL); }
        @Override public void onRender(WorldRenderContext ctx) {
            if (mc.world == null) return;
            Vec3d cam = ctx.camera().getPos();
            Matrix4f mat = ctx.matrixStack().peek().getPositionMatrix();
            float td = ctx.tickCounter().getTickDelta(true);
            BufferBuilder b = RenderUtil.begin();
            for (PlayerEntity e : mc.world.getPlayers()) {
                if (e == mc.player) continue;
                Vec3d pos = e.getLerpedPos(td);
                Box bb = e.getBoundingBox().offset(pos.subtract(e.getPos())).offset(cam.negate());
                RenderUtil.box(b, mat, bb, 255, 60, 60, 255);
            }
            RenderUtil.end(b);
        }
    }

    public static class Tracers extends Module {
        public Tracers() { super("Tracers", Category.VISUAL); }
        @Override public void onRender(WorldRenderContext ctx) {
            if (mc.player == null || mc.world == null) return;
            Vec3d cam = ctx.camera().getPos();
            Matrix4f mat = ctx.matrixStack().peek().getPositionMatrix();
            Vec3d look = Vec3d.fromPolar(ctx.camera().getPitch(), ctx.camera().getYaw());
            float td = ctx.tickCounter().getTickDelta(true);
            BufferBuilder b = RenderUtil.begin();
            for (PlayerEntity e : mc.world.getPlayers()) {
                if (e == mc.player) continue;
                Vec3d p = e.getLerpedPos(td).subtract(cam).add(0, e.getHeight() / 2, 0);
                RenderUtil.line(b, mat, (float) look.x, (float) look.y, (float) look.z, (float) p.x, (float) p.y, (float) p.z, 255, 255, 255, 255);
            }
            RenderUtil.end(b);
        }
    }

    public static class NameTags extends Module {
        public NameTags() { super("Name Tags", Category.VISUAL); }

        private static String describe(ItemStack st) {
            String n = st.getName().getString();
            if (st.getCount() > 1) n += " x" + st.getCount();
            if (st.isDamageable() && st.getMaxDamage() > 0) {
                int pct = (st.getMaxDamage() - st.getDamage()) * 100 / st.getMaxDamage();
                n += " " + pct + "%";
            }
            return n;
        }

        private static int durabilityColor(ItemStack st) {
            if (!st.isDamageable() || st.getMaxDamage() <= 0) return 0xFFFFFFFF;
            int pct = (st.getMaxDamage() - st.getDamage()) * 100 / st.getMaxDamage();
            return pct > 60 ? 0xFF55FF55 : pct > 30 ? 0xFFFFFF55 : 0xFFFF5555;
        }

        @Override public void onRender(WorldRenderContext ctx) {
            if (mc.world == null || ctx.consumers() == null) return;
            Vec3d cam = ctx.camera().getPos();
            MatrixStack ms = ctx.matrixStack();
            VertexConsumerProvider vcp = ctx.consumers();
            TextRenderer tr = mc.textRenderer;
            float td = ctx.tickCounter().getTickDelta(true);
            for (PlayerEntity e : mc.world.getPlayers()) {
                if (e == mc.player) continue;
                Vec3d p = e.getLerpedPos(td).subtract(cam).add(0, e.getHeight() + 0.5, 0);
                float hp = e.getHealth() + e.getAbsorptionAmount();
                int hpColor = hp > 14 ? 0xFF55FF55 : hp > 7 ? 0xFFFFFF55 : 0xFFFF5555;

                // linie od gory do dolu: [tekst, kolor]
                java.util.List<Object[]> lines = new java.util.ArrayList<>();
                ItemStack main = e.getMainHandStack();
                ItemStack off = e.getOffHandStack();
                if (!main.isEmpty()) lines.add(new Object[]{"Reka: " + describe(main), durabilityColor(main)});
                if (!off.isEmpty()) lines.add(new Object[]{"Offhand: " + describe(off), durabilityColor(off)});
                EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
                String[] labels = {"Helm", "Klata", "Spodnie", "Buty"};
                for (int i = 0; i < slots.length; i++) {
                    ItemStack st = e.getEquippedStack(slots[i]);
                    if (!st.isEmpty()) lines.add(new Object[]{labels[i] + ": " + describe(st), durabilityColor(st)});
                }
                lines.add(new Object[]{e.getName().getString() + " [" + String.format("%.1f", hp / 2f) + " hearts]", hpColor});

                float s = (float) Math.max(0.025, p.length() * 0.0035);
                ms.push();
                ms.translate(p.x, p.y, p.z);
                ms.multiply(ctx.camera().getRotation());
                ms.scale(s, -s, s);
                // ostatnia linia (nick) na y=0, reszta wyzej
                for (int i = 0; i < lines.size(); i++) {
                    String text = (String) lines.get(i)[0];
                    int color = (Integer) lines.get(i)[1];
                    float y = -(lines.size() - 1 - i) * 10f;
                    tr.draw(text, -tr.getWidth(text) / 2f, y, color, false, ms.peek().getPositionMatrix(), vcp,
                            TextRenderer.TextLayerType.SEE_THROUGH, 0x66000000, 15728880);
                }
                ms.pop();
            }
            if (vcp instanceof VertexConsumerProvider.Immediate imm) imm.draw();
        }
    }

    public static class StorageEsp extends Module {
        public StorageEsp() { super("Storage Esp", Category.VISUAL); }
        @Override public void onRender(WorldRenderContext ctx) {
            if (mc.world == null || mc.player == null) return;
            Vec3d cam = ctx.camera().getPos();
            Matrix4f mat = ctx.matrixStack().peek().getPositionMatrix();
            int pcx = mc.player.getChunkPos().x, pcz = mc.player.getChunkPos().z;
            BufferBuilder b = RenderUtil.begin();
            for (int cx = pcx - 6; cx <= pcx + 6; cx++) {
                for (int cz = pcz - 6; cz <= pcz + 6; cz++) {
                    var chunk = mc.world.getChunk(cx, cz);
                    for (BlockEntity be : chunk.getBlockEntities().values()) {
                        int r = 0, g = 0, bl = 0;
                        if (be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity) { r = 255; g = 170; }
                        else if (be instanceof EnderChestBlockEntity) { r = 170; bl = 255; }
                        else if (be instanceof ShulkerBoxBlockEntity) { r = 255; g = 100; bl = 255; }
                        else continue;
                        RenderUtil.box(b, mat, new Box(be.getPos()).offset(cam.negate()), r, g, bl, 255);
                    }
                }
            }
            RenderUtil.end(b);
        }
    }

    public static class ItemEsp extends Module {
        public ItemEsp() { super("Item Esp", Category.VISUAL); }
        @Override public void onRender(WorldRenderContext ctx) {
            if (mc.world == null) return;
            Vec3d cam = ctx.camera().getPos();
            Matrix4f mat = ctx.matrixStack().peek().getPositionMatrix();
            float td = ctx.tickCounter().getTickDelta(true);
            BufferBuilder b = RenderUtil.begin();
            for (Entity e : mc.world.getEntities()) {
                if (!(e instanceof ItemEntity)) continue;
                Vec3d pos = e.getLerpedPos(td);
                Box bb = e.getBoundingBox().offset(pos.subtract(e.getPos())).offset(cam.negate());
                RenderUtil.box(b, mat, bb, 80, 255, 255, 255);
            }
            RenderUtil.end(b);
        }
    }

    public static class Fullbright extends Module {
        public Fullbright() { super("Fullbright", Category.VISUAL); }
        @Override public void onTick() {
            if (mc.player == null) return;
            mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1000, 0, false, false, false));
        }
        @Override public void onDisable() {
            if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    }

    // ---------------- UTILITY ----------------
    public static class AutoRespawn extends Module {
        public AutoRespawn() { super("Auto Respawn", Category.UTILITY); }
        @Override public void onTick() {
            if (mc.player != null && mc.currentScreen instanceof DeathScreen) mc.player.requestRespawn();
        }
    }
}
