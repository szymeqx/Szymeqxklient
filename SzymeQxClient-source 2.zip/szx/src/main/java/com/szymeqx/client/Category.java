package com.szymeqx.client;

public enum Category {
    PVP("Pvp"), MOVEMENT("Movement"), VISUAL("Visual"), UTILITY("Utility");
    public final String title;
    Category(String t) { title = t; }
}
